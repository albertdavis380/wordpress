<?php
// Exit if direct access attempt to the file for example with a browser
defined( 'ABSPATH' ) || exit;